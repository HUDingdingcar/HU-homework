var assert = require('assert');
//assert.strictEqual(1,'1'); 
assert.equal(1,'1'); 